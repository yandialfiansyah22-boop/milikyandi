# Jawaban Praktikum: Yandi Alfiansyah 10224052

## Bagian 1: Pemanasan

1. Pada aturan `nav a.active:hover { color: red; }`:
   - Selector: `nav a.active:hover`
   - Deklarasi: `color: red;`
   - Property: `color`
   - Value: `red`
   - Pseudo-class: `:hover`

2. Default display:
   - Block: `p`, `li` (secara default `list-item`), `h2`
   - Inline: `span`, `a`, `strong`

3. Paragraf yang menjadi hijau adalah **A dan B**, karena keduanya merupakan elemen `p` yang berada di dalam elemen ber-class `box`. C dan D tidak menjadi hijau oleh selector `.box p`.

4. Warnanya **merah**, karena selector `#title` memiliki specificity lebih tinggi daripada `.heading` dan `h1`.

5. Tag tidak ditutup dalam urutan yang benar. Elemen `<strong>` dibuka di dalam `<p>`, jadi `</strong>` harus ditulis sebelum `</p>`. Perbaikan: `<p>Hello <strong>world</strong></p>`.

## Bagian 3: Prediksi Selector Golf

P1. Dengan aturan `p { color: blue; }`, `section p { color: green; }`, dan `.note { color: orange; }`:
- (a) “Weekly hack nights.”: **green**, karena cocok dengan `p` dan `section p`; selector `section p` lebih spesifik.
- (b) “Bring your own laptop.”: **orange**, karena cocok dengan `.note`, yang lebih spesifik daripada selector elemen.
- (c) “© 2026 Student Affairs”: **blue**, karena hanya cocok dengan `p`.

P2. Specificity tertinggi ke terendah:
1. `#tech p`
2. `.club p`
3. `main section p`
4. `p`

Setelah diuji (hasil sebenarnya):
- (a) green
- (b) orange
- (c) blue

## Bagian 4: Box model

Q1 (content-box): Lebar terlihat dari tepi border ke tepi border adalah `300 + 16 + 16 + 1 + 1 = 334px`. Margin 24px berada di luar border sehingga tidak termasuk dalam lebar terlihat kartu.

Q2 (border-box): `width: 300px` sudah mencakup content, padding, dan border, sehingga lebar dari tepi border ke tepi border menjadi **300px**. Margin tetap berada di luar ukuran tersebut.

Pengecekan DevTools:
- Content: 300px (nilai width CSS pada contoh `content-box`)
- Padding: 16px kiri dan kanan
- Border: 1px kiri dan kanan
- Margin: 24px di setiap sisi
- Catatan: sesuaikan angka dengan hasil inspeksi section pada halaman yang benar-benar dibuat.

## Bagian 5: Tabel debug

| # | Baris/area | Bug | Perbaikan | Cara menemukannya |
|---|---|---|---|---|
| 1 | `body` | Property `colour` bukan property CSS yang valid | Ganti menjadi `color` | DevTools/validasi CSS |
| 2 | `header` | Kurang titik koma setelah deklarasi `background` | Tambahkan `;` | Membaca aturan CSS |
| 3 | `.Card` dan class section | Nama selector/class tidak konsisten; kapitalisasi juga berbeda | Gunakan `.card` dan `class="card"` | Membandingkan selector dan HTML |
| 4 | `#news-list` | ID CSS tidak sama dengan ID HTML `newsList` | Samakan menjadi `id="news-list"` | Membandingkan selector dan atribut |
| 5 | `font-size` | `18 px` memiliki spasi yang tidak valid di antara angka dan satuan | Ganti menjadi `18px` | DevTools/validasi CSS |
| 6 | `footer` | Nilai `centre` tidak valid untuk `text-align` | Ganti menjadi `center` | DevTools/validasi CSS |
| 7 | Heading | `<h1>` ditutup dengan `</h2>` | Tutup dengan `</h1>` | Membaca kode/validator |
| 8 | Link About | Tanda kutip pada atribut `href` tidak ditutup dengan benar | Gunakan `href="about.html"` | Validator HTML |
| 9 | Gambar | Elemen `img` tidak memiliki atribut `alt` | Tambahkan teks alternatif yang bermakna | Validator/aksesibilitas |

Catatan: atribut class pada kode soal juga ditulis dengan markup yang rusak (`class="car&#x64;*"*`). Perbaikannya adalah `class="card"`.

## Bagian 6: Tabel Code Review

| # | Baris/area | Masalah | Mengapa penting | Perbaikan saya |
|---|---|---|---|---|
| 1 | Awal dokumen | Tidak ada `<!DOCTYPE html>` | Menghindari mode rendering lama/quirks | Tambahkan doctype HTML5 |
| 2 | Elemen `html` | Tidak ada atribut `lang` | Membantu teknologi bantu dan mesin pencari mengenali bahasa | Gunakan `<html lang="id">` |
| 3 | Header dan konten | Menggunakan banyak `div` generik | Struktur dan makna dokumen kurang jelas | Gunakan `header`, `nav`, `main`, `section`, dan `footer` |
| 4 | Judul | Judul utama bukan elemen heading yang tepat | Struktur heading membantu navigasi dan aksesibilitas | Gunakan satu `h1`, lalu `h2` untuk bagian |
| 5 | Header CSS | Lebar tetap `1200px` | Dapat melampaui layar kecil | Gunakan `width: 100%` dan `max-width` pada wadah |
| 6 | Link navigasi | Menggunakan `!important` | Membuat aturan CSS lebih sulit ditimpa dan dipelihara | Hapus `!important`, atur specificity dengan wajar |
| 7 | Konten CSS | Teks berwarna `#bbbbbb` pada latar putih berkontras rendah | Menyulitkan pembacaan | Gunakan warna teks yang lebih gelap |
| 8 | Sidebar CSS | `.sidebar` memakai float tetapi tidak digunakan di HTML | CSS tidak terpakai dan membingungkan | Hapus aturan yang tidak diperlukan |
| 9 | Heading About/Contact | Menggunakan inline style dan `div` sebagai judul | Sulit dipelihara dan struktur heading tidak semantik | Gunakan `h2` dan class CSS |
| 10 | Spasi | Banyak `<br>` dipakai untuk mengatur jarak | Presentasi seharusnya diatur lewat CSS | Gunakan `margin` dan `padding` |
| 11 | Gambar | Tidak memiliki `alt` | Pembaca layar tidak mendapat deskripsi gambar | Tambahkan `alt` yang sesuai |
| 12 | Formulir | Input tidak memiliki `label`; email menggunakan `type="text"` | Aksesibilitas dan validasi input berkurang | Tambahkan label terhubung dan gunakan `type="email"` |
| 13 | Tombol | `onclick="alert('Sent!')"` memberi kesan pesan terkirim padahal tidak ada proses pengiriman | Perilaku tidak mewakili fungsi sebenarnya | Gunakan form dan jelaskan bahwa backend diperlukan untuk mengirim data |
| 14 | Navigasi | Semua tautan menggunakan `href="#"` | Tautan tidak mengarah ke bagian yang berguna | Arahkan ke ID section yang sesuai |
| 15 | Footer | Class `footer` tidak diberi aturan CSS | Tampilan footer tidak konsisten dengan bagian lain | Tambahkan aturan footer yang jelas |

Refleksi:

1. Masalah yang paling sulit disadari hanya dengan melihat browser adalah tidak adanya label pada input dan tidak adanya teks alternatif pada gambar. Halaman masih dapat terlihat normal, tetapi aksesibilitasnya berkurang.
2. Masalah tetap penting meskipun halaman terlihat berfungsi karena kode harus mudah dipelihara, responsif, aksesibel, valid, dan dapat dipahami oleh browser serta teknologi bantu.
3. Saya akan memeriksa struktur HTML, menggunakan DevTools, dan menjalankan W3C Validator sebelum mengumpulkan tugas.

## Bagian 7: Exit ticket

1. Aturan CSS terdiri dari selector yang memilih elemen HTML dan blok deklarasi yang berisi property serta value. Property menentukan aspek tampilan yang diubah, sedangkan value menentukan nilai tampilannya.
2. Konsep yang masih perlu saya latih adalah specificity ketika beberapa selector mengatur property yang sama.
3. Saya sekarang bisa membuat struktur halaman HTML semantik, menghubungkan file CSS eksternal, dan menggunakan selector dasar untuk mengatur tampilan.
